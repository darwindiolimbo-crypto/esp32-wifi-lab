# ESP32 Wi-Fi Lab WebUI 3.1 — enhanced assessment source

This package preserves the embedded ESP32 WebUI and adds a vendor-neutral router security assessment form, WPS exposure review guidance, passive AP fingerprint summary, additional console commands, JSON report export, and Python report validation. The original source's offline attack-pattern simulations remain simulations and do not send attack traffic.

## Build

Use the included `.github/workflows/build-esp32.yml` in GitHub Actions, or install Arduino CLI plus Espressif's Arduino ESP32 core and compile `firmware/esp32_wifi_lab`. Local compilation was not run in the packaging environment because Arduino CLI is not installed.

## Tools

- `python3 tools/validate_firmware_zip.py /path/to/esp32-wifi-lab-firmware.zip` checks the supplied binary ZIP's internal headers/partition-table consistency.
- Export a router report from the WebUI, then run `python3 tools/router_audit.py esp32-router-assessment.json`.
- `config/router-security-baseline.json` defines a starter checklist across common router vendors. It is not an exhaustive CVE/model database.

## Important limits

SSID scans only expose beacon metadata and do not reliably prove WPS state, admin configuration, firmware support status, or firewall behavior. Record evidence from the router's admin interface/vendor documentation. This package does not implement operational WPS PIN cracking, credential theft, forced disconnections, or access-control bypass attacks.

## Partition error

See `FLASHING_AND_BOOT_ERROR.md`. Source/archive validation cannot prove the physical flash contents or a successful boot.
