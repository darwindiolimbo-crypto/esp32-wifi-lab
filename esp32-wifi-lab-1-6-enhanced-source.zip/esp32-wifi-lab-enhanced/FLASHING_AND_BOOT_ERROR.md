# Partition-table boot error: verified facts and next diagnostic

Reported boot error: `partition 0 invalid magic number 0x2221`, followed by `failed to verify partition table` and `boot: load partition table error`.

The previously supplied firmware ZIP passed its CRC check. The merged image is 4,194,304 bytes; the partition table starts with `AA 50`, and the table bytes match the embedded table at offset `0x8000`. The merged image has a bootloader image at `0x1000` and app image at `0x10000`. These checks establish internal archive consistency only, not the physical flash contents.

For separate binary flashing on a classic ESP32, use the offsets produced by the matching build: bootloader `0x1000`, partition table `0x8000`, application `0x10000` (plus any other images/offsets listed by that build). A correctly generated merged image can be written at `0x0` only when the flashing tool supports its embedded offsets. Never flash the application binary at `0x0`.

**Next decisive check:** read back physical flash around `0x8000` with a supported ESP32 flash tool and compare against the partition binary. If readback at `0x8000` does not start `AA 50`, investigate incorrect offset, wrong image, incomplete write, flash mode/tool configuration, or a different partition layout. Do not claim fixed without flash readback and a successful boot log.

This environment does not have Arduino CLI installed and cannot compile/flash the board locally. The included GitHub Actions workflow compiles the source; hardware verification remains required.
