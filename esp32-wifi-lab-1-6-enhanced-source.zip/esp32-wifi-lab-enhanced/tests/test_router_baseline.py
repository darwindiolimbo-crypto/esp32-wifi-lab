import json, pathlib, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class BaselineTests(unittest.TestCase):
 def test_schema_and_unique_ids(self):
  d=json.loads((ROOT/'config/router-security-baseline.json').read_text())
  ids=[x['id'] for x in d['checks']]
  self.assertEqual(len(ids),18); self.assertEqual(len(ids),len(set(ids)))
 def test_vendor_neutral(self):
  d=json.loads((ROOT/'config/router-security-baseline.json').read_text())
  self.assertGreaterEqual(len(d['vendors_in_scope']),15)
if __name__=='__main__': unittest.main()
