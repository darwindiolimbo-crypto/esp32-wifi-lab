# Targeted WebUI and local audit enhancement

This patch preserves the existing project layout and current API endpoints.

## Changes
- Adds local-only password/PIN pattern checks to the embedded dashboard and external preview UI. Inputs are evaluated in browser JavaScript, not sent to the ESP32, stored, or logged.
- Expands scan results with BSSID, channel, RSSI, and the advertised authentication mode.
- Makes scan failures return an HTTP error JSON response and returns HTTP 429 if a scan is already marked active.
- Changes `/api/status` to structured JSON including AP IP, station connection status, uptime, and free heap.
- Updates the external WebUI to attempt the live scan API instead of always returning a preview-only message.

## Limits
- This source has not been compiled or tested on hardware here.
- Local password/PIN checks are heuristic only; they do not attempt authentication or crack passwords.
- The external `webui/index.html` is still a separate file from the embedded HTML in the `.ino`; keeping them manually synchronized remains necessary until a build process embeds the external file.
- No firmware flashing or erasing is performed.
