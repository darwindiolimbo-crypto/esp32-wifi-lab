# WebUI 3.1 source update — memory and passive diagnostics

- Added `memory` command displaying free heap, minimum-ever free heap, largest 8-bit-capable heap block, and PSRAM size where supported.
- Added `analyze` command for passive indicators: open/WEP advertised security, duplicate SSIDs, and same-SSID security-mode differences. These are heuristic indicators and require manual verification.
- Added an 8-second server-side Wi-Fi scan cooldown and capped JSON output to 25 access points to reduce memory pressure.
- Kept the existing dashboard, AP setup, target selection, password/PIN local heuristics, and routes.
- Updated external HTML and embedded firmware dashboard together.

This source update does not implement credential cracking, access-control bypass, or disruptive attacks.

Validation: source-level edits only. Compilation and hardware testing have not been performed. Confirm the ESP32 Arduino core provides `ESP.getMinFreeHeap()`, `ESP.getPsramSize()`, and `heap_caps_get_largest_free_block()` before flashing.

- Added a local “Result to plain text” utility to both the external and embedded dashboard. It formats JSON, expands common escaped newlines/tabs and Unicode escapes, strips ANSI terminal color sequences, and removes HTML markup without executing pasted content. Includes copy support and a `plaintext` console command. Input is browser-local and capped at 20,000 characters.

## Security scenario modules

- Added offline simulations for WPS PIN attack patterns, password-guessing patterns, deauthentication/disruption, evil-twin/rogue AP indicators, and access-control bypass patterns.
- Simulations produce detection clues and defensive recommendations; they do not transmit attack traffic, guess credentials, bypass controls, or disconnect devices.
- Added `tools_plaintext.py`, an offline Python helper that formats JSON/log/HTML text without executing pasted content. Example: `python tools_plaintext.py results.txt` or `cat results.txt | python tools_plaintext.py`.
- JavaScript modules are included in both external dashboard files and the firmware-embedded page.
- Not compiled or hardware-tested.
