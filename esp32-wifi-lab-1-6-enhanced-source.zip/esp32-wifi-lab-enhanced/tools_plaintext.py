#!/usr/bin/env python3
"""Offline helper for formatting ESP32 lab output; does not scan or attack networks."""
import argparse, html, json, re, sys

def plain(text: str) -> str:
    try:
        obj = json.loads(text)
        text = obj if isinstance(obj, str) else json.dumps(obj, indent=2, ensure_ascii=False)
    except (ValueError, TypeError):
        text = text.replace(r"\r\n", "\n").replace(r"\n", "\n").replace(r"\r", "\n").replace(r"\t", "  ")
    text = re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", text)
    text = re.sub(r"<script\b[^>]*>[\s\S]*?</script\s*>", " ", text, flags=re.I)
    text = re.sub(r"<style\b[^>]*>[\s\S]*?</style\s*>", " ", text, flags=re.I)
    text = re.sub(r"<br\s*/?>|</(?:p|div|li|tr|h[1-6]|pre)\s*>", "\n", text, flags=re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = html.unescape(text)
    text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", text)
    return re.sub(r"\n{3,}", "\n\n", text).strip()

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('file', nargs='?', help='input file; reads stdin if omitted')
    args = ap.parse_args()
    try:
        data = open(args.file, encoding='utf-8', errors='replace').read() if args.file else sys.stdin.read()
        print(plain(data))
    except OSError as e:
        ap.error(str(e))

if __name__ == '__main__':
    main()
