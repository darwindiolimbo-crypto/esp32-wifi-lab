#!/usr/bin/env python3
"""Read-only ZIP/header/offset validation; never accesses physical flash."""
import sys, zipfile
from pathlib import Path
p=Path(sys.argv[1] if len(sys.argv)>1 else "esp32-wifi-lab-firmware.zip")
required={"esp32_wifi_lab.ino.bootloader.bin":(0,b"\xE9"),"esp32_wifi_lab.ino.partitions.bin":(0,b"\xAA\x50"),"esp32_wifi_lab.ino.bin":(0,b"\xE9"),"esp32_wifi_lab.ino.merged.bin":(0x1000,b"\xE9")}
if not p.is_file(): raise SystemExit(f"ZIP not found: {p}")
with zipfile.ZipFile(p) as z:
    bad=z.testzip()
    if bad: raise SystemExit(f"ZIP CRC failure: {bad}")
    names=set(z.namelist()); failed=False
    for name,(off,magic) in required.items():
        if name not in names: print("MISSING:",name); failed=True; continue
        b=z.read(name); ok=b[off:off+len(magic)]==magic
        print(f"{name}: {len(b)} bytes; header@{off:#x}={b[off:off+len(magic)].hex(' ').upper()} {'PASS' if ok else 'FAIL'}")
        failed |= not ok
    if "esp32_wifi_lab.ino.partitions.bin" in names and "esp32_wifi_lab.ino.merged.bin" in names:
        part=z.read("esp32_wifi_lab.ino.partitions.bin"); merged=z.read("esp32_wifi_lab.ino.merged.bin")
        ok=len(merged)==4*1024*1024 and part[:0xC0]==merged[0x8000:0x8000+0xC0]
        print("4MiB image and partition-table match:","PASS" if ok else "FAIL"); failed |= not ok
    print("Physical flash is not read or verified by this tool.")
    if failed: raise SystemExit(1)
