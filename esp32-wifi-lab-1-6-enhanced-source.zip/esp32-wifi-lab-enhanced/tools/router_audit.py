#!/usr/bin/env python3
"""Validate and summarize an ESP32 Wi-Fi Lab router assessment JSON report."""
import json, sys
from pathlib import Path
ALLOWED={"unknown","pass","finding","na"}
def main():
    if len(sys.argv)!=2: raise SystemExit("Usage: python3 tools/router_audit.py report.json")
    p=Path(sys.argv[1]); data=json.loads(p.read_text(encoding="utf-8"))
    if data.get("schema")!="esp32-wifi-lab-router-audit-v1": raise SystemExit("Unsupported report schema")
    checks=data.get("checks")
    if not isinstance(checks,dict) or not checks: raise SystemExit("No checks found")
    bad=[k for k,v in checks.items() if not isinstance(v,dict) or v.get("status") not in ALLOWED]
    if bad: raise SystemExit("Invalid check status: "+", ".join(bad))
    counts={s:sum(v["status"]==s for v in checks.values()) for s in sorted(ALLOWED)}
    print("Router assessment:", data.get("router",{}).get("manufacturer") or "manufacturer not recorded", data.get("router",{}).get("model") or "model not recorded")
    print("Checks:",len(checks)," | ".join(f"{k}: {v}" for k,v in counts.items()))
    print("Evidence limitation: report values are user-recorded; this validator does not probe routers.")
if __name__=="__main__": main()
